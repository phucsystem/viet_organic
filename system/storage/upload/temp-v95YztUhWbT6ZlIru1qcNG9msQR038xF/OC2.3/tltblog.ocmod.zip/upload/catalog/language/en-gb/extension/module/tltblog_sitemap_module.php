<?php
// Heading
$_['heading_title']    = 'Blog entries';
$_['heading_blogs']    = 'Blogs';
$_['heading_tags']     = 'Tags';
