<?php
// Text
$_['text_path'] = 'Blog';
$_['text_error'] = 'Page Not Found!';
$_['text_related'] = 'Related Products';
$_['text_tags'] = '<i class="fa fa-tags"></i>';
$_['text_tax'] = 'Ex Tax:';
