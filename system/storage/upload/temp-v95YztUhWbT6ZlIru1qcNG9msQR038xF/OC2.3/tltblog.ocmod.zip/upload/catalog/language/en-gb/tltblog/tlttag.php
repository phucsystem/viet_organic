<?php
// Text
$_['text_title'] = 'Blog';
$_['text_path'] = 'Blog';
$_['text_error'] = 'Tag not found!';

